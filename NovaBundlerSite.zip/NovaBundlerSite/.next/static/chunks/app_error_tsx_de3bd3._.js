(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_error_tsx_de3bd3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_error_tsx_de3bd3._.js",
  "chunks": [
    "static/chunks/app_error_tsx_6c72c3._.js"
  ],
  "source": "dynamic"
});
