(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_d96937._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_d96937._.js",
  "chunks": [
    "static/chunks/[root of the server]__47c63b._.css",
    "static/chunks/node_modules_next_8044b8._.js",
    "static/chunks/node_modules_framer-motion_dist_es_90e399._.js",
    "static/chunks/node_modules_@react-aria_interactions_dist_9e16a3._.js",
    "static/chunks/node_modules_2f7486._.js",
    "static/chunks/app_9e4cf7._.js",
    "static/chunks/node_modules_@heroui_dom-animation_dist_index_mjs_d7acad._.js"
  ],
  "source": "dynamic"
});
