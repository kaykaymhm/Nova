(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_818aa4._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_818aa4._.js",
  "chunks": [
    "static/chunks/app_page_tsx_9fdd4f._.js"
  ],
  "source": "dynamic"
});
